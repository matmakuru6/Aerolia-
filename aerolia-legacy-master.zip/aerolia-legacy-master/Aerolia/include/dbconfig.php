<?php

    // Nombre del servidor donde se aloja la base de datos
    define("DB_HOST", "localhost");
    
    // Nombre del usuario destinado para la manipulación de la base y su contraseña
    define("DB_USER", "root");
    define("DB_PASS", "n0m3l0s3");
    
    // Nombre de la base de datos
    define("DB_NAME", "aerolia");
    
    // Codificación de la base de datos
    define("DB_ENC", "utf8");
    
?>