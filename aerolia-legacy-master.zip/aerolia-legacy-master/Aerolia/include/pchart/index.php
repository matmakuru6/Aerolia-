<?php
 /* If you navigate here, then you should see the examples */

 header('Location: examples/');
 exit();
?>